package com.task.keyvalue;

import java.util.Arrays;

import com.task.keybalue.listener.ErrorListener;

/**
 * @author Sidian Fang
 * @since 1.0.0
 */
public class KeyValueStore extends AbstractKeyValueStore {

	public KeyValueStore(ErrorListener listener) {
		super(listener);
	}

	/**
	 * @throws Exception
	 * 
	 */
	public void accept(String kvPairs) {

		// validate the input string
		try {
			validate(kvPairs);
		} catch (Exception e) {
			listener.onError("msg", e);
			return;
		}

		String[] kvPairsArray = kvPairs.split(",");
		for (String kvPair : kvPairsArray) {
			String[] kv = kvPair.split("=");
			String key = kv[0].trim();
			String value = kv[1].trim();

			boolean isPreValueInteger = false;
			boolean isNewValueInteger = false;
			int newValue = 0;
			int preValue = 0;

			// checking if the new value is int
			try {
				newValue = Integer.parseInt(value);
				isNewValueInteger = true;

			} catch (NumberFormatException nfe) {
				// log as info

			}

			// checking if key exists and its value is int
			if (store.containsKey(key)) {
				try {
					preValue = Integer.parseInt(store.get(key));
					isPreValueInteger = true;

				} catch (NumberFormatException nfe) {
					// log as info

				}
			}

			if (isPreValueInteger && isNewValueInteger) {
				store.put(key, String.valueOf(preValue + newValue));
				continue;
			}

			store.put(key, value);

		}
	}

	/**
	 * Return all element in key value pair from key-value store
	 * 
	 * @return Result in String.
	 */
	public String display() {

		String[] keys = store.keySet().toArray(new String[store.size()]);
		Arrays.sort(keys, String.CASE_INSENSITIVE_ORDER);

		StringBuilder sb = new StringBuilder();
		for (Object key : keys) {
			sb = sb.append(String.format("%s=%s\n", key, store.get(key)));
		}

		return sb.toString();
	}
}
