package com.task.keybalue.listener;

/**
 * @author Sidian Fang
 * @since 1.0.0
 */
public interface ErrorListener {
	void onError(String msg);

	void onError(String msg, Exception e);
}
