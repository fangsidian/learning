package com.task.keyvalue;

/**
 * @author Sidian Fang
 * @since 1.0.0
 */
public interface KeysAndValues {
	void accept(String kvPairs);

	String display();
}
