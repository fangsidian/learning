package com.task.keyvalue;

import org.junit.Test;

import com.task.keybalue.listener.LoggingErrorListener;

public class KeyValueStoreTest {

	@Test
	public void test_() {
		KeyValueStore kvStore = new KeyValueStore(new LoggingErrorListener());

		kvStore.accept("one=two , Three=four, 5=6,14=X");
		System.out.println(kvStore.display());
	}

	@Test
	public void test_2() {
		KeyValueStore kvStore = new KeyValueStore(new LoggingErrorListener());

		kvStore.accept("14=15,A=B52,dry=D.R.Y, 14=7,14=4,dry=Don't Repeat Yourself");
		System.out.println(kvStore.display());
	}

}
