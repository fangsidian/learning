package com.task.keyvalue;

import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.task.keybalue.listener.ErrorListener;

/**
 * @author Sidian Fang
 * @since 1.0.0
 */
public abstract class AbstractKeyValueStore implements KeysAndValues {
	Map<String, String> store = new HashMap<String, String>();

	ErrorListener listener;

	/**
	 * Constructor to pass listener as part of D.I. process
	 */
	public AbstractKeyValueStore(ErrorListener listener) {
		this.listener = listener;
	}

	/**
	 * 1) Checking if the key is form of alaphic number. 2) Checking for atomic
	 * group.
	 */
	void validate(String value) throws Exception {
		Pattern pattern = Pattern.compile("regex string");

		String[] kvPairsArray = value.split(",");
		for (String kvPair : kvPairsArray) {
			String[] kv = kvPair.split("=");
			String key = kv[0].trim();

			Matcher matcher = pattern.matcher(key);
			int matches = 0;
			while (matcher.find()) {
				matches++;
			}

			if (matches == 0) {
				throw new Exception("fsd");
			}
		}
	}
}
