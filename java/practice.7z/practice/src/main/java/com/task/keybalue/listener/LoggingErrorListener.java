package com.task.keybalue.listener;

/**
 * @author Sidian Fang
 * @since 1.0.0
 */
import java.util.logging.Level;
import java.util.logging.Logger;

public class LoggingErrorListener implements ErrorListener {
	private Logger logger = Logger.getLogger("KeyValueStore Logger");

	public void onError(String msg) {
		logger.log(Level.SEVERE, msg);

	}

	public void onError(String msg, Exception e) {
		logger.log(Level.SEVERE, msg, e);
	}

}
